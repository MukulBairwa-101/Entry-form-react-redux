import React from "react"
import './App.css';
import Datalist from "./Components/Datalist";

function App() {
  return (
    <div className="App">
      <Datalist />
      
    </div>
  );
}

export default App;
